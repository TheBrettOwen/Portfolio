//File name: passwordManager.cpp
//
//Brett Owen
//3/25/2019
//CS2308.255 
//Seaman
//
//Class cpp file for the password Manager. Contains the functions specified in the assignment, and the default constructor. 


#include "passwordManager.h"
#include <string>
#include <iostream>
using namespace std;

passwordManager::passwordManager() {
	string username = "bmo23";
	string password = "ZZZJJJ{{{";

}
string passwordManager::encrypt(string oldUse){ //dynamically allocates an array of chars to apply the algorithm (specified in the assignment paper) and assigns it to a string .
	int length = oldUse.length(); 
	char* enArr = new char[length]; 
	string s(oldUse); 
	for (int i = 0; i < oldUse.length(); i++){ 
		*(enArr+i) = ((s[i]-33)+25)% 94 + 33; 
	}
	string newpass(enArr);  
	delete enArr; 
return newpass; 
}
bool passwordManager::meetsCriteria(string pass){
	cout << "Checking to see if meets criteria" << endl;
	bool u = false;
	bool d = false;  
	bool low = false; 
	string pArray(pass);
	if  (pass.length() >= 8) { 
		for (int i = 0; i < pass.length(); i++){
			if (isupper(pArray[i])) { u = true;} 
			if (isdigit(pArray[i])) { d = true;}
			if (islower(pArray[i])) { low = true;} 
		}
		if (u == true && d == true && low == true){
			return true; 
		}
		else { 
			return false;
		}
	}
	else 
		return false;  
}
void passwordManager::setUsername(string newU){
	username = newU; 
return;
}
string passwordManager::getUsername(){
return username; 
}

void passwordManager::setEncryptedPassword(string pass){
	password = pass;
	return;
}
string passwordManager::getEncryptedPassword(){
return password; 
}
bool passwordManager::setNewPassword(string pass){
		if (meetsCriteria(pass)) {
			setEncryptedPassword(pass);
			return true;  
		}
		else {
			return false; 
		}
}
bool passwordManager::authenticate(string newPass){
	if (newPass.length() == password.length()){
		if(encrypt(newPass) == password) {
			password = newPass;  
		}
		else	{
			return false;
		} 
	}
	else {
		return false;
	}
}