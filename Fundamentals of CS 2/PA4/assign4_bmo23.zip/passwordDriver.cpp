//File Name passwordDriver.cpp
//
//Brett Owen
//Date 3/25/2019
//Assignment 4 
//CS 2308.255 Spring 2019
//Jill Seaman
//Driver program for the class program manager. Allows user to change password if they know the old one for a specific netID

#include <iostream>
#include <fstream>
#include "passwordManager.h"
using namespace std;

int main(){
	passwordManager pl[3]; //array of 3 entities of the passwordManager class. pl meaning 'password list'
	
	ifstream inputPass; 
	inputPass.open("passwords.txt");
	int count = 0; 
	string tempFile = ""; // makes a temporary file for the program to write info to that will eventually be put into the getUsername and getEncryptedPassword program
	
	while (inputPass >> tempFile) {
		inputPass >> ws; 
		pl[count].setUsername(tempFile); 
		cout << pl[count].getUsername() << endl; 
		inputPass >> tempFile;
		pl[count].setEncryptedPassword(tempFile); 
		cout << pl[count].getEncryptedPassword() << endl;
		count++;
	}
	inputPass.close(); 
	
	string uInput = " ";
	bool u = false;  //bool to store whether username is one of the NetId's or not
	int pIndex  = 0; //index of the array of the class to manipulate.
	cout << "Welcome to the New Password Manager!" << endl; 
	cout << "Please enter your Username:" << endl; 
	cin >> uInput; 
	for (int i = 0; i < 3; i++) {
		if (uInput == pl[i].getUsername()) {
			u = true;
			pIndex = i;  
		}
	}
	if (u) {
		cout << "Please enter your old Password:" << endl;
		cin >> uInput;
		if (!pl[pIndex].authenticate(uInput)){
			cout << "Here's the criteria for the new Password:" << endl;
			cout << "1. Longer than 8 characters" << endl << "2. At least one uppercase letter" << endl;
			cout << "3. At least one lowercase letter." << endl << "4. At least one lowercase letter" << endl;
			cout << "Please enter your new password" << endl; 
			cin >> uInput; 
			if (pl[pIndex].meetsCriteria(uInput)) {
				pl[pIndex].setEncryptedPassword(pl[pIndex].encrypt(uInput)); 
				cout << "Password has been changed for NetID:" << pl[pIndex].getUsername() <<endl;  
			}
			else {cout << "New password does NOT meet criteria" << endl; }
		}
		else {cout << "Old password is incorrect." << endl;}
	}
	else {cout << "NetID not valid, password not changed." << endl;} 
return 0;
}
