#ifndef PASSWORDMANAGER_H
#define PASSWORDMANAGER_H
#include <string>

class passwordManager
{
    	public:
       		bool setNewPassword(std::string);
       		bool authenticate(std::string);
		bool meetsCriteria(std::string);
       		void setUsername(std::string);
       		std::string getUsername();
       		void setEncryptedPassword(std::string);
       		std::string getEncryptedPassword();
		std::string encrypt(std::string);
		passwordManager();
	private:
       		std::string username;
       		std::string password;
       		
       
};

#endif // PASSWORDMANAGER_H
